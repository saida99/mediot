package org.ids.exceptions;

public class DoctorException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7258113104324899956L;
	
	public DoctorException(String message) {
		super(message);
	}
	
}
